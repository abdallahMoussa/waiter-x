<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <title>أحد العملاء يريد التواصل</title>
</head>

<body>

    <h1>اشتراك جديد</h1>
    <p><strong>الاسم:</strong> <?php echo e($name); ?></p>
    <p><strong>البريد:</strong> <?php echo e($email); ?></p>
    <p><strong>رقم الهاتف:</strong> <?php echo e($phone); ?></p>
    <p><strong>الرسالة:</strong> <?php echo e($content); ?></p>
</body>

</html><?php /**PATH C:\Users\Mr_Moussa\Desktop\waiter-x-landing page\waiter-x\resources\views/emails/email.blade.php ENDPATH**/ ?>