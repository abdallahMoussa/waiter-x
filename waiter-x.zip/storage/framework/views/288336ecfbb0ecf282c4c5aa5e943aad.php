

<?php $__env->startSection('content'); ?>
<section id="home" class="hero-section-wrapper-5">

    <div id="pricingPage" class="hero-section hero-style-5 img-bg" style="background-image: url('assets/img/hero/hero-5/hero-bg2.svg'); ">
        <div dir="rtl" class="container">
            <div class="row">
                <div class="col-lg-12 px-5">
                    <div class="hero-content-wrapper row">
                        <div class="row ">
                            <div class="col-5"></div>
                            <div class="col-2 text-xl-center text-primary">
                                <h6 class="font  ">باقة الكاشير</h6>
                                <span class="my-2 d-block">800 ج.م</span>
                            </div>
                            <div class="col-2 text-xl-center text-primary">
                                <h6 class="font ">باقة الويتر</h6>
                                <span class="my-2 d-block">1.400 ج.م</span>
                            </div>
                            <div class="col-2 text-xl-center text-primary">
                                <h6 class="font ">باقة إكس ويتر </h6>
                                <span class="my-2 d-block">1800 ج.م</span>
                            </div>
                        </div>
                        <hr />
                        <table class="col-12">
                            <tr class="col-12" style="border-bottom: 1px solid gainsboro;">
                                <td class="col-6">لوحة التحكم</td>
                                <td class="col-2"><i class="lni lni-checkmark-circle text-primary my-3"></i></td>
                                <td class="col-2"><i class="lni lni-checkmark-circle text-primary"></i></td>
                                <td class="col-"><i class="lni lni-checkmark-circle text-primary"></i></td>
                            </tr>
                            <tr class="col-12" style="border-bottom: 1px solid gainsboro;">
                                <td class="col-6">لوحة المطبخ</td>
                                <td class="col-2"><i class="lni lni-checkmark-circle text-primary my-3"></i></td>
                                <td class="col-2"><i class="lni lni-checkmark-circle text-primary"></i></td>
                                <td class="col-"><i class="lni lni-checkmark-circle text-primary"></i></td>
                            </tr>
                            <tr class="col-12" style="border-bottom: 1px solid gainsboro;">
                                <td class="col-6">إداره الطلبات </td>
                                <td class="col-2"><i class="lni lni-checkmark-circle text-primary my-3"></i></td>
                                <td class="col-2"><i class="lni lni-checkmark-circle text-primary"></i></td>
                                <td class="col-"><i class="lni lni-checkmark-circle text-primary"></i></td>
                            </tr>
                            <tr class="col-12" style="border-bottom: 1px solid gainsboro;">
                                <td class="col-6">إداره المخزون</td>
                                <td class="col-2"><i class="lni lni-checkmark-circle text-primary my-3"></i></td>
                                <td class="col-2"><i class="lni lni-checkmark-circle text-primary"></i></td>
                                <td class="col-"><i class="lni lni-checkmark-circle text-primary"></i></td>
                            </tr>
                            <tr class="col-12" style="border-bottom: 1px solid gainsboro;">
                                <td class="col-6">إداره الفئات</td>
                                <td class="col-2"><i class="lni lni-checkmark-circle text-primary my-3"></i></td>
                                <td class="col-2"><i class="lni lni-checkmark-circle text-primary"></i></td>
                                <td class="col-"><i class="lni lni-checkmark-circle text-primary"></i></td>
                            </tr>


                            <tr class="col-12" style="border-bottom: 1px solid gainsboro;">
                                <td class="col-6">إداره المنيو</td>
                                <td class="col-2"><i class="lni lni-checkmark-circle text-primary my-3"></i></td>
                                <td class="col-2"><i class="lni lni-checkmark-circle text-primary"></i></td>
                                <td class="col-"><i class="lni lni-checkmark-circle text-primary"></i></td>
                            </tr>

                            <tr class="col-12" style="border-bottom: 1px solid gainsboro;">
                                <td class="col-6"> الاشعارات والتنبيهات</td>
                                <td class="col-2"><i class="lni lni-checkmark-circle text-primary my-3"></i></td>
                                <td class="col-2"><i class="lni lni-checkmark-circle text-primary"></i></td>
                                <td class="col-"><i class="lni lni-checkmark-circle text-primary"></i></td>
                            </tr>
                            <tr class="col-12" style="border-bottom: 1px solid gainsboro;">
                                <td class="col-6">إداره المسئوولين</td>
                                <td class="col-2 font"> _</td>
                                <td class="col-2"><i class="lni lni-checkmark-circle text-primary"></i></td>
                                <td class="col-"><i class="lni lni-checkmark-circle text-primary my-3"></i></td>
                            </tr>
                            <tr class="col-12" style="border-bottom: 1px solid gainsboro;">
                                <td class="col-6">إداره الطاولات</td>
                                <td class="col-2">_</td>
                                <td class="col-2"><i class="lni lni-checkmark-circle text-primary"></i></td>
                                <td class="col-"><i class="lni lni-checkmark-circle text-primary my-3"></i></td>
                            </tr>
                            <tr class="col-12" style="border-bottom: 1px solid gainsboro;">
                                <td class="col-6"> الاونلاين منيو</td>
                                <td class="col-2">_</td>
                                <td class="col-2"><i class="lni lni-checkmark-circle text-primary"></i></td>
                                <td class="col-"><i class="lni lni-checkmark-circle text-primary my-3"></i></td>
                            </tr>
                            <tr class="col-12" style="border-bottom: 1px solid gainsboro;">
                                <td class="col-6"> الاحصائيات والجداول</td>
                                <td class="col-2">_</td>
                                <td class="col-2">_</td>
                                <td class="col-"><i class="lni lni-checkmark-circle text-primary my-3"></i></td>
                            </tr>
                            <tr class="col-12" style="border-bottom: 1px solid gainsboro;">
                                <td class="col-6"> تحليل البيانات</td>
                                <td class="col-2">_</td>
                                <td class="col-2">_</td>
                                <td class="col-"><i class="lni lni-checkmark-circle text-primary my-3"></i></td>
                            </tr>

                        </table>


                    </div>
                    <div class="contact-section contact-style-3 contact-style-2">
                        <div class="container">
                            <div class="row justify-content-center animate__animated animate__fadeIn ">
                                <div class="col-lg-12">
                                    <div class="contact-form-wrapper">
                                        <form id="myForm" method="POST" action="<?php echo e(route('subscribe')); ?>">
                                            <?php echo csrf_field(); ?>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="single-input">
                                                        <input required type="text" id="name" name="name" class="form-input" placeholder="الاسم " />
                                                        <i class="lni lni-phone"></i>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="single-input">
                                                        <input required type="text" id="number" name="phone" class="form-input" placeholder="رقم الهاتف" />
                                                        <i class="lni lni-phone"></i>
                                                    </div>
                                                </div>
                                                <div class="col-md-12">
                                                    <div class="single-input">
                                                        <input required type="email" id="email" name="email" class="form-input" placeholder="البريد الالكتروني" />
                                                        <i style="font-style: normal; font-size: 16pt; margin-top: -6px;">@</i>
                                                    </div>
                                                </div>


                                                <div class="col-md-12">
                                                    <div class="single-input">
                                                        <select class="form-select" aria-label="Default select example">
                                                            <option value="1">باقة الكاشير</option>
                                                            <option value="2">باقة الويتر</option>
                                                            <option value="3">باقة إكس ويتر</option>
                                                        </select>
                                                    </div>
                                                </div>

                                            </div>
                                            <div class="g-recaptcha col-md-12" data-sitekey="6Lc20ZInAAAAAAmchiwawDXFPpU78NZIq4Yl0zbD"></div>

                                            <div class="d-flex justify-content-center  pt-10">
                                                <button type="submit" id="subscribe" class="button radius-30 m-auto d-flex flex-row-reverse gap-1">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                                                        <path fill="currentColor" d="M18 10h-4V6a2 2 0 0 0-4 0l.071 4H6a2 2 0 0 0 0 4l4.071-.071L10 18a2 2 0 0 0 4 0v-4.071L18 14a2 2 0 0 0 0-4z" />
                                                    </svg>
                                                    <span> إشتراك</span>
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <?php if(session('successSub')): ?>
                    <div class="alert alert-success mt-3">
                        <?php echo e(session('successSub')); ?>

                    </div>
                    <?php elseif(session('error')): ?>
                    <div class="alert alert-danger mt-3">
                        <?php echo e(session('error')); ?>

                    </div>
                    <?php endif; ?>


                </div>
            </div>
        </div>
    </div>
</section>
<script>
    (function() {

        window.onload = function() {
            window.setTimeout(fadeout, 300);
        };

        function fadeout() {
            document.querySelector(".preloader").style.opacity = "0";
            document.querySelector(".preloader").style.display = "none";
        }
    })();
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mr_Moussa\Desktop\waiter-x-landing page\waiter-x\resources\views/prices.blade.php ENDPATH**/ ?>