<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <title>أحد العملاء يريد التواصل</title>
</head>

<body>

    <h1>اشتراك جديد</h1>
    <p><strong>الاسم:</strong> {{ $name }}</p>
    <p><strong>البريد:</strong> {{ $email }}</p>
    <p><strong>رقم الهاتف:</strong> {{ $phone }}</p>
    <p><strong>الرسالة:</strong> {{ $content }}</p>
</body>

</html>